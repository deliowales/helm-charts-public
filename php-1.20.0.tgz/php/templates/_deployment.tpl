{{- define "php.deployment.topologySpreadConstraints" -}}
{{- $spread := .Values.deployment.topologySpreadConstraints -}}
{{- $all := ternary $spread (list $spread) (kindIs "slice" $spread) -}}
topologySpreadConstraints:
{{- range $all }}
  - maxSkew: {{ required "topologySpreadConstraints: every entry needs maxSkew" .maxSkew }}
    topologyKey: {{ required "topologySpreadConstraints: every entry needs topologyKey" .topologyKey }}
    whenUnsatisfiable: {{ required "topologySpreadConstraints: every entry needs whenUnsatisfiable" .whenUnsatisfiable }}
    # Scopes the skew calculation to the revision being rolled out. Without it the
    # old ReplicaSet's pods still count while they terminate, so the scheduler
    # measures balance against a moving target and the new pods land wherever the
    # stale numbers point. Kubernetes 1.27+.
    matchLabelKeys:
      - pod-template-hash
    labelSelector:
      matchLabels:
        app.kubernetes.io/name: {{ $.Values.application.name | lower }}
{{- end }}
{{- end }}

{{- define "php.deployment.nginx.imageURL" -}}
  {{- printf "%s/%s:%s" .Values.cloud.containerRegistryURL .Values.nginx.image.repository .Values.nginx.image.tag }}
{{- end -}}

{{- define "php.deployment.nightwatch.imageURL" -}}
  {{- if contains "/" .Values.nightwatch.image.repository -}}
    {{- printf "%s:%s" .Values.nightwatch.image.repository .Values.nightwatch.image.tag }}
  {{- else -}}
    {{- printf "%s/%s:%s" .Values.cloud.containerRegistryURL .Values.nightwatch.image.repository .Values.nightwatch.image.tag }}
  {{- end -}}
{{- end -}}

{{/*
Set the nodeSelector toleration
*/}}
{{- define "node.deployment.nodeSelector.toleration" -}}
  {{- if eq .Values.deployment.nodeSelector.toleration "cpu" -}}
    scheduling.cast.ai/compute-optimized: "true"
  {{- else -}}
    scheduling.cast.ai/memory-optimized: "true"
  {{- end }}
{{- end -}}
